import {
  Column,
  Entity,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { ContractType } from "./contract-type.entity";
import { Level } from "./level.entity";
import { User } from "./user.entity";
import { Status } from "./status.entity";
import { Language } from "./language.entity";
import { JobApplication } from "./job-application.entity";

@Entity()
export class JobPost {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column("varchar", { length: 45 })
  companyName!: string;

  @Column("varchar", { length: 45 })
  title!: string;

  @Column("int")
  salary!: number;

  @Column("varchar", { length: 40 })
  logo!: string;

  @Column("varchar", { length: 500 })
  description!: string;

  @Column("varchar", { length: 25 })
  location!: string;

  @ManyToOne(() => ContractType, (contractType) => contractType.jobPosts)
  contractType!: ContractType;

  @ManyToOne(() => Level, (level) => level.jobPosts)
  level!: Level;

  @ManyToOne(() => User, (user) => user.jobPosts)
  author!: User;

  @ManyToOne(() => Status, (status) => status.jobPosts)
  status!: Status;

  @ManyToMany(() => Language, (language) => language.jobPosts)
  @JoinTable({ name: "job_posts_languages" })
  languages!: Language[];

  @ManyToMany(() => User, (user) => user.favouritePosts)
  favouritedBy!: User[];

  @OneToMany(() => JobApplication, (application) => application.jobPost)
  applications!: JobApplication[];
}
